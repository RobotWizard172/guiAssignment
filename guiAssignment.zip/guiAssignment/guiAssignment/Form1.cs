﻿/*
 * Name: Jeff Koss
 * Date: 03/19/23
 * Class: MS-539 Programming Concepts
 * Professor: Jill Coddington
 * Assignment: GUI Assignment
 * ETA on completion: 3 Hours
 * */

/* 
 * It took me only 2 hours to complete, the assignment
 * was not hard, I was able to reuse code and download
 * free pictures off of the internet.
 * I wanted to keep it simple for this assignment,
 * so I went with a button/show picture scheme.
 */



// This is kind of like header files in C++
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Namespace - in this case a place to make code.
namespace guiAssignment
{
    public partial class Form1 : Form
    {
        public Form1() // This makes the form
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) // what happens when you click on a button
        { 
            pictureBox1.Image = Image.FromFile("D:/School Classes/Software Engineering/MS539 Programming Concepts/Week1/Homework/guiAssignment/myGuitar.jpg");
            pictureBox1.Visible = true;
            // The above code is used to display the correct piture assigned to the button
        }

        private void pictureBox1_Click(object sender, EventArgs e) // This is the picture box used to display the image that is assigned to each button
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile("D:/School Classes/Software Engineering/MS539 Programming Concepts/Week1/Homework/guiAssignment/redColor.png");
            pictureBox1.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile("D:/School Classes/Software Engineering/MS539 Programming Concepts/Week1/Homework/guiAssignment/myTacos.jpg");
            pictureBox1.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile("D:/School Classes/Software Engineering/MS539 Programming Concepts/Week1/Homework/guiAssignment/myNumber.jpg");
            pictureBox1.Visible = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile("D:/School Classes/Software Engineering/MS539 Programming Concepts/Week1/Homework/guiAssignment/myHoliday.jpg");
            pictureBox1.Visible = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string age = textBox1.Text;

            if (age == "48")
            {
             MessageBox.Show("Correct! At the time I made this program I was 48 years old!\n I was born 3/30/1974");
            }
            else
            {
                MessageBox.Show("Wrong, please try again!");
            }

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                MessageBox.Show("Correct!");
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                MessageBox.Show("Not Correct!");
            }
        }
    }
}
